using System;
using UnityEngine;
using UnityEngine.SceneManagement;
using Photon.Pun;
using Photon.Realtime;

namespace ProjectD
{
    public class GameManager : MonoBehaviourPunCallbacks
    {
        [Header("Character Settings")]
        [SerializeField] private string playerPrefabName = "PlayerCharacter";

        private bool isCharacterSpawned = false;

        private void Start()
        {
            Debug.Log("RAID 씬 진입 성공.");

            // 방장 유저 또는 이미 룸 동기화가 완비된 상태에서 넘어온 경우 즉시 생성
            if (PhotonNetwork.IsConnectedAndReady && PhotonNetwork.InRoom)
            {
                SpawnPlayerCharacter();
            }
        }

        // ★ 난입 유저용 안전장치 콜백
        // 씬 로드 직후 미세하게 룸 입장 정보가 늦게 동기화될 때 처리
        public override void OnJoinedRoom()
        {
            Debug.Log("난입 클라이언트: 룸 입장 완료 상태 확인 및 스폰.");
            SpawnPlayerCharacter();
        }

        private void SpawnPlayerCharacter()
        {
            if (isCharacterSpawned) return;

            // 리스폰 위치 겹침 방지 랜덤 벡터
            Vector3 spawnPosition = new Vector3(UnityEngine.Random.Range(-3f, 3f), 1f, UnityEngine.Random.Range(-3f, 3f));

            // [포톤 네트워크 멀티 소환] -> Resources/PlayerCharacter 프리팹 필수
            PhotonNetwork.Instantiate(playerPrefabName, spawnPosition, Quaternion.identity);

            isCharacterSpawned = true;
            Debug.Log($"{PhotonNetwork.NickName} 캐릭터 멀티 동기화 완료.");
        }

        #region Photon Callbacks
        public override void OnLeftRoom()
        {
            // 방을 나가면 BOOT 씬(0번)으로 이동
            SceneManager.LoadScene(0);
        }

        // 기존 방장 및 플레이어들이 새로운 난입 유저를 감지했을 때 호출되는 포톤 콜백
        public override void OnPlayerEnteredRoom(Photon.Realtime.Player other)
        {
            Debug.LogFormat("<color=cyan>[난입 수신]</color> {0}님이 레이드 도중 난입 참여했습니다.", other.NickName);
        }

        public override void OnPlayerLeftRoom(Photon.Realtime.Player other)
        {
            Debug.LogFormat("{0}님이 레이드 방에서 퇴장했습니다.", other.NickName);
        }
        #endregion

        #region Public Methods
        public void LeaveRoom()
        {
            PhotonNetwork.LeaveRoom();
        }
        #endregion
    }
}
