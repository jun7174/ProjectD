using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;

namespace ProjectD
{
    public class Launcher : MonoBehaviourPunCallbacks
    {
        #region Public Fields
        [Tooltip("The Ui Panel to let the user enter name, connect and play")]
        [SerializeField] private GameObject controlPanel;
        [Tooltip("The UI Label to inform the user that the connection is in progress")]
        [SerializeField] private GameObject progressLabel;
        #endregion

        #region Private Fields
        string gameVersion = "1";
        // ★ 방법 B를 위한 전용 SQL 로비 정의
        private TypedLobby raidSqlLobby = new TypedLobby("RaidSqlLobby", LobbyType.SqlLobby);
        #endregion

        #region MonoBehaviour CallBacks
        void Awake()
        {
            // 방장이 씬을 바꾸면 다 같이 바뀌도록 동기화 설정 
            PhotonNetwork.AutomaticallySyncScene = true;
        }

        void Start()
        {
            progressLabel.SetActive(false);
            controlPanel.SetActive(true);
        }
        #endregion

        #region Public Methods
        public void Connect()
        {
            progressLabel.SetActive(true);
            controlPanel.SetActive(false);

            if (PhotonNetwork.IsConnectedAndReady)
            {
                // ★ 이미 연결되어 있다면 안전하게 SQL 로비 진입 시도
                PhotonNetwork.JoinLobby(raidSqlLobby);
            }
            else
            {
                PhotonNetwork.GameVersion = gameVersion;
                // ★ ConnectUsingSettings() 뒤에 곧바로 JoinLobby를 붙이면 절대 안 됩니다. 콜백을 기다려야 합니다.
                PhotonNetwork.ConnectUsingSettings();
            }
        }
        #endregion

        #region MonoBehaviourPunCallbacks Callbacks 
        public override void OnConnectedToMaster()
        {
            Debug.Log("서버 접속 성공! SQL 로비 진입을 시도합니다.");
            // ★ 마스터 서버 접속이 확인된 이 타이밍에 SQL 로비로 들어갑니다.
            PhotonNetwork.JoinLobby(raidSqlLobby);
        }

        public override void OnDisconnected(DisconnectCause cause)
        {
            Debug.LogWarningFormat("연결 끊김: {0}", cause);
            progressLabel.SetActive(false);
            controlPanel.SetActive(true);
        }

        // 로비 진입 성공 시 LOBBY 씬을 로드합니다.
        public override void OnJoinedLobby()
        {
            Debug.Log("SQL 로비 진입 성공! LOBBY 씬으로 이동합니다.");

            // ★ 중요: 포톤의 연결 상태(로비 상태)를 유지하면서 안전하게 씬을 이동하려면
            // SceneManager 대신 PhotonNetwork.LoadLevel을 사용하는 것이 안전합니다.
            PhotonNetwork.LoadLevel("Lobby");
        }
        #endregion
    }
}
