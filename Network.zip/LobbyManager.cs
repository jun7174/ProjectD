using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using System.Collections.Generic;
using TMPro;

namespace ProjectD
{
    public class LobbyManager : MonoBehaviourPunCallbacks
    {
        [Header("UI References")]
        [SerializeField] private Button createRoomButton;
        [SerializeField] private Transform roomListContent;
        [SerializeField] private GameObject roomEntryPrefab;

        private TypedLobby raidSqlLobby = new TypedLobby("RaidSqlLobby", LobbyType.SqlLobby);

        private void Start()
        {
            if (createRoomButton != null)
                createRoomButton.onClick.AddListener(OnClickCreateRoom);

            // ★ 씬이 로드되었을 때 로비 상태라면 즉시 서버에 방 목록을 요청합니다.
            if (PhotonNetwork.InLobby)
            {
                RequestRoomList();
            }
            else if (PhotonNetwork.IsConnectedAndReady)
            {
                // 로비가 풀렸다면 다시 진입
                PhotonNetwork.JoinLobby(raidSqlLobby);
            }
        }

        public override void OnJoinedLobby()
        {
            Debug.Log("로비 재진입 성공, 방 목록을 요청합니다.");
            RequestRoomList();
        }

        private void RequestRoomList()
        {
            // ★ SQL 로비에 방 목록을 강제 요청하는 함수 (OnRoomListUpdate를 트리거함)
            PhotonNetwork.GetCustomRoomList(raidSqlLobby, "1");
        }

        public void OnClickCreateRoom()
        {
            string roomName = $"{PhotonNetwork.NickName}'s Raid Room";
            RoomOptions roomOptions = new RoomOptions
            {
                MaxPlayers = 4,
                IsVisible = true, // 방장이 레이드 씬으로 떠나도 SQL 목록에 계속 노출됨
                IsOpen = true,    // 언제든 중간 난입 허용
                PublishUserId = true
            };

            Debug.Log($"방 생성 시도: {roomName}");
            // ★ 방을 개설할 때 세 번째 인자로 SQL 로비를 명시해 줍니다.
            PhotonNetwork.CreateRoom(roomName, roomOptions, raidSqlLobby);
        }

        // 실시간 방 목록 수신
        public override void OnRoomListUpdate(List<RoomInfo> roomList)
        {
            Debug.Log($"[성공] OnRoomListUpdate 호출됨! 현재 감지된 방 개수: {roomList.Count}");

            foreach (Transform child in roomListContent)
            {
                Destroy(child.gameObject);
            }

            foreach (RoomInfo room in roomList)
            {
                if (room.RemovedFromList || !room.IsVisible) continue;

                GameObject entry = Instantiate(roomEntryPrefab, roomListContent);

                TMP_Text roomText = entry.GetComponentInChildren<TMP_Text>();
                if (roomText != null)
                {
                    roomText.text = $"{room.Name} ({room.PlayerCount}/{room.MaxPlayers})";
                }

                Button entryButton = entry.GetComponent<Button>();
                if (entryButton != null)
                {
                    string targetRoomName = room.Name;
                    entryButton.onClick.AddListener(() => {
                        Debug.Log($"{targetRoomName} 방에 난입 입장을 시도합니다.");
                        PhotonNetwork.JoinRoom(targetRoomName);
                    });
                }
            }
        }

        public override void OnJoinedRoom()
        {
            Debug.Log("방 입장 성공!");
            if (PhotonNetwork.IsMasterClient)
            {
                Debug.Log("마스터 클라이언트가 RAID 씬을 로드합니다.");
                PhotonNetwork.LoadLevel("Raid");
            }
        }
    }
}
